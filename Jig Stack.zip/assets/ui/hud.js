/**
 * Tetris HUD client: receives server state, sends actions (left, right, rotate, softDrop, hardDrop, reset).
 * Soft drop: mousedown/touchstart -> softDropDown, mouseup/touchend -> softDropUp.
 * Keyboard: Arrow keys or WASD (A left, D right, W rotate, S soft drop), Space hard drop, R reset.
 * Music: played from UI via HTML5 Audio so mute button can pause it (engine has no per-player mute API).
 */

(function () {
  // Resolve assets base URL from this script's src (e.g. .../assets/ui/hud.js -> .../assets)
  var scriptEl = document.currentScript;
  var scriptSrc = scriptEl ? scriptEl.src : '';
  var assetsBase = scriptSrc.replace(/\/ui\/hud\.js(\?.*)?$/i, '');
  /** One-shot sound when game ends (play only on transition to GAME_OVER). */
  var gameOverSoundUrl = assetsBase ? assetsBase + '/audio/game-over.mp3' : '';
  /** In-game looping background music (play only when status is RUNNING). */
  var soundtrackUrl = assetsBase ? assetsBase + '/audio/soundtrack.mp3' : '';
  var lineClearSoundUrl = assetsBase ? assetsBase + '/audio/line-clear.mp3' : '';
  var buttonClickSoundUrl = assetsBase ? assetsBase + '/audio/button-click.mp3' : '';
  /** One-shot sound when player levels up. */
  var levelUpSoundUrl = assetsBase ? assetsBase + '/audio/level-up.mp3' : '';
  /** Trim start of button click (seconds) to skip silent lead-in. */
  var buttonClickTrimStart = 0.35;

  /** Last level we saw (to play level-up sound only when level increases). */
  var lastLevel = undefined;

  var soundtrackEl = null;
  function getSoundtrack() {
    if (soundtrackEl) return soundtrackEl;
    if (!soundtrackUrl) return null;
    var audio = new window.Audio(soundtrackUrl);
    audio.loop = true;
    audio.volume = 0.5;
    soundtrackEl = audio;
    return audio;
  }

  var lastAppliedMusicMuted = undefined;
  var lastAppliedSfxMuted = undefined;
  /** Last status we saw (to detect transition to GAME_OVER and play game-over sound once). */
  var lastStatus = '';
  /** Current SFX muted state (for future SFX: check before playing). */
  window.__tetrisSfxMuted = false;

  function setMusicMuted(muted) {
    var st = getSoundtrack();
    if (!st) return;
    if (muted) {
      st.pause();
    }
    /* When unmuted, playback is started only when status is RUNNING (see applySoundtrackForStatus). */
  }

  /** Play game-over sound once (only when transitioning to GAME_OVER; respects SFX mute). */
  function playGameOverSound() {
    if (window.__tetrisSfxMuted || !gameOverSoundUrl) return;
    var audio = new window.Audio(gameOverSoundUrl);
    audio.volume = 0.6;
    audio.play().catch(function () {});
  }

  /** Start or stop soundtrack based on status and mute. Call when status or musicMuted changes. */
  function applySoundtrackForStatus(status, musicMuted) {
    var st = getSoundtrack();
    if (!st) return;
    if (status === 'RUNNING' && !musicMuted) {
      st.volume = 0.5;
      st.play().catch(function () {});
    } else {
      st.pause();
    }
  }

  function send(action) {
    if (typeof hytopia !== 'undefined' && hytopia.sendData) {
      hytopia.sendData({ action });
    }
  }

  function updateLeaderboard(leaderboard) {
    if (!leaderboard || typeof leaderboard !== 'object') return;
    var panel = document.getElementById('leaderboard-panel');
    var statusEl = document.getElementById('leaderboard-status');
    var rowsEl = document.getElementById('leaderboard-rows');
    if (!panel || !rowsEl) return;
    var status = leaderboard.status === 'online' ? 'online' : 'offline';
    var selfId = leaderboard.selfPlayerId;
    panel.classList.toggle('offline', status !== 'online');
    if (statusEl) {
      statusEl.textContent = status === 'online' ? 'Online' : 'Offline';
      statusEl.className = 'leaderboard-status ' + status;
    }
    var rows = Array.isArray(leaderboard.rows) ? leaderboard.rows : [];
    if (rows.length === 0) {
      rowsEl.innerHTML = '<div class="leaderboard-empty">No scores yet</div>';
      return;
    }
    var html = '';
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      var rank = r.rank != null ? r.rank : i + 1;
      var name = (r.name != null && r.name !== '') ? String(r.name) : (r.playerId || '—');
      var score = r.score != null ? Number(r.score) : 0;
      var isSelf = selfId != null && String(r.playerId) === String(selfId);
      html += '<div class="leaderboard-row' + (isSelf ? ' self' : '') + '" data-player-id="' + (r.playerId || '') + '">';
      html += '<span class="rank">' + rank + '</span>';
      html += '<span class="name" title="' + name.replace(/"/g, '&quot;') + '">' + name.replace(/</g, '&lt;') + '</span>';
      html += '<span class="score">' + score + '</span>';
      html += '</div>';
    }
    rowsEl.innerHTML = html;
  }

  function playLineClearSound() {
    if (window.__tetrisSfxMuted || !lineClearSoundUrl) return;
    var audio = new window.Audio(lineClearSoundUrl);
    audio.volume = 0.6;
    audio.play().catch(function () {});
  }

  function playBlockLandSound() {
    if (window.__tetrisSfxMuted || !blockLandSoundUrl) return;
    var audio = new window.Audio(blockLandSoundUrl);
    audio.volume = 0.6;
    audio.play().catch(function () {});
  }

  function playButtonClickSound() {
    if (window.__tetrisSfxMuted || !buttonClickSoundUrl) return;
    var audio = new window.Audio(buttonClickSoundUrl);
    audio.volume = 0.6;
    audio.currentTime = buttonClickTrimStart;
    audio.play().catch(function () {});
  }

  function playLevelUpSound() {
    if (window.__tetrisSfxMuted || !levelUpSoundUrl) return;
    var audio = new window.Audio(levelUpSoundUrl);
    audio.volume = 0.6;
    audio.play().catch(function () {});
  }

  function showScoreBurst(points, lines) {
    if (lines > 0) playLineClearSound();
    var el = document.createElement('div');
    el.className = 'score-burst';
    el.textContent = '+' + points;
    if (lines === 4) {
      el.classList.add('tetris-burst');
    } else if (lines === 3) {
      el.classList.add('triple-burst');
    }
    document.body.appendChild(el);
    setTimeout(function () {
      el.remove();
    }, 900);
    if (lines >= 3) {
      document.body.classList.add('screen-shake');
      setTimeout(function () {
        document.body.classList.remove('screen-shake');
      }, 300);
    }
  }

  function updateUI(data) {
    const el = function id(name) { return document.getElementById(name); };
    if (data.type === 'lineClearBurst') {
      showScoreBurst(data.points, data.linesCleared);
      return;
    }
    if (data.type === 'pieceLock') {
      playBlockLandSound();
      return;
    }
    if (data.leaderboard !== undefined) updateLeaderboard(data.leaderboard);
    if (data.musicMuted !== undefined) {
      var muteBtn = el('btn-mute-music');
      if (muteBtn) {
        muteBtn.classList.toggle('muted', data.musicMuted);
        muteBtn.setAttribute('aria-label', data.musicMuted ? 'Unmute music' : 'Mute music');
        muteBtn.title = data.musicMuted ? 'Unmute music' : 'Mute music';
        muteBtn.textContent = data.musicMuted ? '\uD83D\uDD07' : '\uD83C\uDFB5';
      }
      if (data.musicMuted !== lastAppliedMusicMuted) {
        lastAppliedMusicMuted = data.musicMuted;
        setMusicMuted(data.musicMuted);
        applySoundtrackForStatus(lastStatus, data.musicMuted);
      }
    }
    if (data.sfxMuted !== undefined) {
      lastAppliedSfxMuted = data.sfxMuted;
      window.__tetrisSfxMuted = data.sfxMuted;
      var sfxBtn = el('btn-mute-sfx');
      if (sfxBtn) {
        sfxBtn.classList.toggle('muted', data.sfxMuted);
        sfxBtn.setAttribute('aria-label', data.sfxMuted ? 'Unmute SFX' : 'Mute SFX');
        sfxBtn.title = data.sfxMuted ? 'Unmute sound effects' : 'Mute sound effects';
        sfxBtn.textContent = data.sfxMuted ? '\uD83D\uDD07' : '\uD83D\uDD0A';
      }
    }
    if (data.score !== undefined) { var s = el('score'); if (s) s.textContent = data.score; }
    if (data.level !== undefined) {
      var l = el('level');
      if (l) l.textContent = data.level;
      if (lastLevel !== undefined && data.level > lastLevel) playLevelUpSound();
      lastLevel = data.level;
    }
    if (data.lines !== undefined) { var n = el('lines'); if (n) n.textContent = data.lines; }
    if (data.status !== undefined) {
      var status = data.status;
      var statusEl = el('status');
      var statusStat = statusEl && statusEl.closest('.stat.status');
      if (statusEl) {
        statusEl.textContent = status;
        statusEl.setAttribute('data-status', status);
      }
      if (statusStat) {
        statusStat.style.display = 'none';
      }
      var overlay = document.getElementById('game-over-overlay');
      if (overlay) {
        if (status === 'GAME_OVER') {
          var scoreEl = document.getElementById('game-over-score');
          var linesEl = document.getElementById('game-over-lines');
          if (scoreEl) scoreEl.textContent = data.score != null ? data.score : 0;
          if (linesEl) linesEl.textContent = data.lines != null ? data.lines : 0;
          overlay.classList.add('visible');
          overlay.setAttribute('aria-hidden', 'false');
          if (lastStatus !== 'GAME_OVER') {
            playGameOverSound();
          }
        } else {
          overlay.classList.remove('visible');
          overlay.setAttribute('aria-hidden', 'true');
        }
      }
      applySoundtrackForStatus(status, lastAppliedMusicMuted === true);
      lastStatus = status;
    }
    if (data.gameStarted !== undefined || data.status !== undefined) {
      var startArea = document.getElementById('start-area');
      var hint = document.getElementById('hint');
      var status = data.status || '';
      if (status === 'NO_PLOT') {
        if (startArea) startArea.style.display = '';
        if (hint) hint.textContent = 'All plots full. Wait for a free plot.';
        var startBtn = document.getElementById('btn-start');
        if (startBtn) startBtn.style.display = 'none';
      } else if (status === 'ASSIGNING_PLOT') {
        if (startArea) startArea.style.display = '';
        if (hint) hint.textContent = 'Assigning plot…';
        var startBtn2 = document.getElementById('btn-start');
        if (startBtn2) startBtn2.style.display = 'none';
      } else if (data.gameStarted) {
        if (startArea) startArea.style.display = 'none';
        if (hint) hint.textContent = 'WASD or arrows: A/← left, D/→ right, W/↑ rotate, S/↓ soft drop. Space hard drop. R or Reset to restart.';
        var startBtn3 = document.getElementById('btn-start');
        if (startBtn3) startBtn3.style.display = '';
      } else {
        if (startArea) startArea.style.display = '';
        if (hint) hint.textContent = 'Click Start to begin the round.';
        var startBtn4 = document.getElementById('btn-start');
        if (startBtn4) startBtn4.style.display = '';
      }
    }
  }

  if (typeof hytopia !== 'undefined' && hytopia.onData) {
    hytopia.onData(updateUI);
  }

  var buttons = document.querySelectorAll('.btn[data-action]');
  for (var i = 0; i < buttons.length; i++) {
    var btn = buttons[i];
    var action = btn.getAttribute('data-action');
    if (!action) continue;

    btn.addEventListener('mousedown', function (e) {
      e.preventDefault();
      playButtonClickSound();
      var a = this.getAttribute('data-action');
      send(a);
      if (a === 'softDropDown') this._softDropSent = true;
    });
    btn.addEventListener('mouseup', function () {
      if (this._softDropSent && this.getAttribute('data-action') === 'softDropDown') {
        send('softDropUp');
        this._softDropSent = false;
      }
    });
    btn.addEventListener('mouseleave', function () {
      if (this._softDropSent) {
        send('softDropUp');
        this._softDropSent = false;
      }
    });
    btn.addEventListener('touchstart', function (e) {
      e.preventDefault();
      playButtonClickSound();
      var a = this.getAttribute('data-action');
      send(a);
      if (a === 'softDropDown') this._softDropSent = true;
    }, { passive: false });
    btn.addEventListener('touchend', function (e) {
      e.preventDefault();
      if (this._softDropSent && this.getAttribute('data-action') === 'softDropDown') {
        send('softDropUp');
        this._softDropSent = false;
      }
    }, { passive: false });
  }

  document.addEventListener('keydown', function (e) {
    var key = e.key;
    if (key === 'ArrowLeft' || key === 'a' || key === 'A') { send('left'); e.preventDefault(); }
    if (key === 'ArrowRight' || key === 'd' || key === 'D') { send('right'); e.preventDefault(); }
    if (key === 'ArrowUp' || key === 'w' || key === 'W') { send('rotate'); e.preventDefault(); }
    if (key === 'ArrowDown' || key === 's' || key === 'S') { send('softDropDown'); e.preventDefault(); _softDropKey = true; }
    if (key === ' ') { send('hardDrop'); e.preventDefault(); }
    if (key === 'r' || key === 'R') { send('reset'); e.preventDefault(); }
  });
  document.addEventListener('keyup', function (e) {
    var key = e.key;
    if ((key === 'ArrowDown' || key === 's' || key === 'S') && typeof _softDropKey !== 'undefined' && _softDropKey) {
      send('softDropUp');
      _softDropKey = false;
    }
  });
  var _softDropKey = false;
})();
